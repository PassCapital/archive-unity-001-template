# Google Play Common Package for Unity

*com.google.play.common*

## Overview

The Google Play Common package provides common files required by some Google
Play packages, such as Play Instant.

This package doesn't provide any features when installed separately.
