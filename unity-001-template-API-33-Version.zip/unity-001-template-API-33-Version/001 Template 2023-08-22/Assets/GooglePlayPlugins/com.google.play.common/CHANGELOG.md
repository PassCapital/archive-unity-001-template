# Changelog for com.google.play.common

## [1.8.1] - 2022-09-08
- Updated plugin's data collection procedure. For more information and the opt-out
  process, please refer to the [data collection](https://github.com/google/play-unity-plugins#data-collection)
  section in README.

## [1.8.0] - 2022-07-06
### New Features
- Incremented version number to match other packages

## [1.7.0] - 2022-02-15
### New Features
- Incremented version number to match other packages

## [1.6.1] - 2022-01-24
### New Features
 - Incremented version number to match other packages

## [1.6.0] - 2021-11-15
### New Features
 - Incremented version number to match other packages

## [1.5.0] - 2021-06-14
### Other
 - Removed ability to compile plugin with Unity 5.6, 2017.1, 2017.2, 2017.3, 2018.1, and 2018.2

## [1.4.0] - 2021-03-08
### Bug Fixes
 - Fixed a build error in 2020.2 related to isHttpError/isNetworkError

## [1.3.0] - 2020-09-30
### New Features
 - Incremented version number to match other packages

## [1.2.0] - 2020-07-27
### New Features
 - Incremented version number to match other packages

## [1.1.1] - 2020-06-08
### New Features
 - Incremented version number to match other packages

## [1.1.0] - 2020-05-04
### New Features
 - Updated documentation

## [1.0.0] - 2020-03-17
### New Features
 - Initial release

