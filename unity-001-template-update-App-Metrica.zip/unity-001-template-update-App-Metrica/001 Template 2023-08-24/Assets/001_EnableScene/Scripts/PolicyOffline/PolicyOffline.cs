using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;

public class PolicyOffline : MonoBehaviour
{
    [SerializeField] private string offlineSceneName = "GameplayGame";
    private UniWebView webView;

    // [SerializeField]
    private string url;

    private bool isInit = false;

    public IEnumerator Start()
    {
        if (UniWebView.IsWebViewSupported)
        {
            
            if (isInit == false)
            {

                if (!UniWebView.IsWebViewSupported) yield return StartCoroutine(LoadAsynchronously());
                webView = gameObject.AddComponent<UniWebView>();
                webView.Frame = new Rect(0, 0, Screen.width, Screen.height);
                webView.OnOrientationChanged += (view, orientation) => {
                    webView.Frame = new Rect(0, 0, Screen.width, Screen.height);
                };
                webView.SetAllowFileAccessFromFileURLs(true);

                url = UniWebViewHelper.StreamingAssetURLForPath("Policy/index.html");
                webView.SetBackButtonEnabled(false);
                webView.OnPageFinished += WebView_OnPageFinished;
                webView.Load(url);
                webView.Show();

                isInit = true;

                Debug.Log("Policy Started");

            }
            else
            {
                webView.Show();
            }

        }
        else
        {
            StartCoroutine(LoadAsynchronously());
        }
    }

    private void Update()
    {
        if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.WindowsEditor)
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                Back();
            }
        }
    }
    
    private void WebView_OnPageFinished(UniWebView webView, int statusCode, string url) // Когда веб-страница загрузилась.
    {
        if (url.Contains("closepolicy"))
        {
            StartCoroutine(LoadAsynchronously());
            webView.Hide();
        }
    }

    private void Back()
    {

        
        webView.Hide();
        StartCoroutine(LoadAsynchronously());

    }

    IEnumerator LoadAsynchronously ()
    {
        AsyncOperation operation = SceneManager.LoadSceneAsync(offlineSceneName);
        

        while (!operation.isDone == false)
        {

            yield return null;
        }

    }

}
