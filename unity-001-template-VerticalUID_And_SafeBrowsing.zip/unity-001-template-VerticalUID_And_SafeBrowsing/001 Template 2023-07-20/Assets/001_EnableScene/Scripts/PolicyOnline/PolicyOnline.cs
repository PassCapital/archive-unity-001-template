using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;

public class PolicyOnline : MonoBehaviour
{
    
    private UniWebView webView;
    private string url = "https://sites.google.com/view/galerabestapp";
    // Start is called before the first frame update

    public void showp()
    {
        StartCoroutine(ShowPolicy());
    }
    public IEnumerator ShowPolicy()
    {
        if (!UniWebView.IsWebViewSupported) { OfflineMode(); yield break;}
        UnityWebRequest unityWebRequest = UnityWebRequest.Get(url);
        yield return unityWebRequest.SendWebRequest();

        if (unityWebRequest.result != UnityWebRequest.Result.Success)  {OfflineMode(); yield break;}
        webView = gameObject.AddComponent<UniWebView>();
        
        webView.Frame = new Rect(0, 0, Screen.width, Screen.height);
        webView.OnOrientationChanged += (view, orientation) =>
        {
            webView.Frame = new Rect(0, 0, Screen.width, Screen.height);
        };
        webView.SetBackButtonEnabled(false);
            
        webView.OnPageErrorReceived += OfflineMode;
            
        webView.OnPageFinished += WebView_OnPageFinished;
        webView.OnPageStarted += WebView_OnPageStarted;
        webView.Load(url);
        Debug.Log("Won");
        webView.Show();
    }

    private void WebView_OnPageStarted(UniWebView webview, string s)
    {
        if(s.Contains("closepolicy")) OfflineMode();
    }

    private void WebView_OnPageFinished(UniWebView webview, int statuscode, string s)
    {
        if(s.Contains("closepolicy")) OfflineMode();
    }

    private void OfflineMode(UniWebView webview, int errorcode, string errormessage)
    {
        webView.Hide();
    }
    

    private void OfflineMode()
    {
        webView.Hide();
    }
}
