namespace Beebyte.Obfuscator
{
	public enum MessageCode
	{
		UnityReflectionMethodNotFound
	}
}