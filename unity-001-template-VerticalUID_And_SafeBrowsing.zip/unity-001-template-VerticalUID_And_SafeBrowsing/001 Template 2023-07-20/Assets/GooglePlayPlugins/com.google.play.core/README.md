# Google Play Core Plugin for Unity

*com.google.play.core*

## Overview

The Google Play Core package provides the
[Play Core Library](//developer.android.com/guide/playcore) required by some
Google Play packages, such as Play Asset Delivery.

This package doesn't provide any features when installed separately.
