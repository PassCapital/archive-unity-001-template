using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Advertisements;

namespace _001_EnableScene.Scripts
{
    public class UnityAds : MonoBehaviour, IUnityAdsInitializationListener, IUnityAdsLoadListener, IUnityAdsShowListener
    {
        [SerializeField] bool testMode = true;

        [Header("ID Devices")]
        [SerializeField] string androidGameId;
        [SerializeField] string iOSGameId;

        [Header("Rewarder Ads")]
        [SerializeField] string androidRewardedUnitIdAdUnitId = "Rewarded_Android";
        [SerializeField] string iOSRewardedAdUnitId = "Rewarded_iOS";

        [Header("Interstitial Ads")]
        [SerializeField] string androidInterstitialAdUnitId = "Interstitial_Android";
        [SerializeField] string iOSInterstitialAdUnitId = "Interstitial_iOS";

        [Header("Banner")]
        [SerializeField] private BannerPosition bannerPosition = BannerPosition.TOP_CENTER;
        [SerializeField] string androidBannerAdUnitId = "Banner_Android";
        [SerializeField] string iOSbannerAdUnitId = "Banner_iOS";

        private string _gameId;
        private string _adRewardedUnitId = null; // This will remain null for unsupported platforms
        private string _adInterstitialUnitId = null; // This will remain null for unsupported platforms
        private string _adBannerUnitId = null; // This will remain null for unsupported platforms.

        void Awake()
        {
            InitializeAds();
        }

        public void InitializeAds()
        {
#if UNITY_IOS
            _gameId = iOSGameId;
            _adRewardedUnitId = iOSRewardedAdUnitId;
            _adInterstitialUnitId = iOSInterstitialAdUnitId;
            _adBannerUnitId = iOSbannerAdUnitId;

#elif UNITY_ANDROID
            _gameId = androidGameId;
            _adRewardedUnitId = androidRewardedUnitIdAdUnitId;
            _adInterstitialUnitId = androidInterstitialAdUnitId;
            _adBannerUnitId = androidBannerAdUnitId;

#elif UNITY_EDITOR
            _gameId = androidGameId; //Only for testing the functionality in the Editor
            _adRewardedUnitId = androidRewardedUnitIdAdUnitId;
            _adInterstitialUnitId = androidInterstitialAdUnitId;
            _adBannerUnitId = androidBannerAdUnitId;
#endif

            if (!Advertisement.isInitialized && Advertisement.isSupported)
            {
                Advertisement.Initialize(_gameId, testMode, this);
            }
        }

        public void LoadRewardedAd()
        {
            // IMPORTANT! Only load content AFTER initialization (in this example, initialization is handled in a different script).
            Debug.Log("Loading Rewarded Ad: " + _adRewardedUnitId);
            Advertisement.Load(_adRewardedUnitId, this);
        }

        public void LoadInterstitialAd()
        {
            // IMPORTANT! Only load content AFTER initialization (in this example, initialization is handled in a different script).
            Debug.Log("Loading Interstitial Ad: " + _adInterstitialUnitId);
            Advertisement.Load(_adInterstitialUnitId, this);
        }

        public void LoadBanner()
        {
            // Load the Ad Unit with banner content:
            Advertisement.Banner.Load(_adBannerUnitId);
        }

        public void ShowRewardedAd()
        {
            // Then show the ad:
            Advertisement.Show(_adRewardedUnitId, this);
        }

        public void ShowInterstitialAd()
        {
            // Then show the ad:
            Advertisement.Show(_adInterstitialUnitId, this);
        }

        public void OnInitializationComplete()
        {
            Debug.Log("Unity Ads initialization complete.");
            LoadRewardedAd();
            ShowRewardedAd();

            //LoadInterstitialAd();
            //ShowInterstitialAd();

            Advertisement.Banner.SetPosition(bannerPosition);
            LoadBanner();
            ShowBannerAd();
        }

        public void OnInitializationFailed(UnityAdsInitializationError error, string message)
        {
            Debug.Log($"Unity Ads Initialization Failed: {error.ToString()} - {message}");
        }

        // Implement the Show Listener's OnUnityAdsShowComplete callback method to determine if the user gets a reward:
        public void OnUnityAdsShowComplete(string adUnitId, UnityAdsShowCompletionState showCompletionState)
        {
            if (adUnitId.Equals(_adRewardedUnitId) && showCompletionState.Equals(UnityAdsShowCompletionState.COMPLETED))
            {
                Debug.Log("Unity Ads Rewarded Ad Completed");
                // Grant a reward.
            }

            if (adUnitId.Equals(_adInterstitialUnitId) && showCompletionState.Equals(UnityAdsShowCompletionState.COMPLETED))
            {
                Debug.Log("Unity Ads Rewarded Ad Completed");
                // Grant a reward.
            }
        }

        // Implement Load and Show Listener error callbacks:
        public void OnUnityAdsFailedToLoad(string adUnitId, UnityAdsLoadError error, string message)
        {
            Debug.Log($"Error loading Ad Unit {adUnitId}: {error.ToString()} - {message}");
            // Use the error details to determine whether to try to load another ad.
        }

        public void OnUnityAdsShowFailure(string adUnitId, UnityAdsShowError error, string message)
        {
            Debug.Log($"Error showing Ad Unit {adUnitId}: {error.ToString()} - {message}");
            // Use the error details to determine whether to try to load another ad.
        }

        public void OnUnityAdsShowStart(string adUnitId) { }
        public void OnUnityAdsShowClick(string adUnitId) { }

        public void OnUnityAdsAdLoaded(string placementId)
        {
            Debug.Log("Unity Ads load complete.");
        }

        // Implement code to execute when the loadCallback event triggers:
        void OnBannerLoaded()
        {
            Debug.Log("Banner loaded");
        }

        // Implement code to execute when the load errorCallback event triggers:
        void OnBannerError(string message)
        {
            Debug.Log($"Banner Error: {message}");
            // Optionally execute additional code, such as attempting to load another ad.
        }

        void ShowBannerAd()
        {
            // Show the loaded Banner Ad Unit:
            Advertisement.Banner.Show(_adBannerUnitId);
        }

        void HideBannerAd()
        {
            // Hide the banner:
            Advertisement.Banner.Hide();
        }

        void OnBannerClicked() { }
        void OnBannerShown() { }
        void OnBannerHidden() { }
    }
}