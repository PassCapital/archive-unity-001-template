# Project

[] Нужно описать здесь все функции проекта

## 2023.06.23 Events Yandex AppMetrica

* Added Yandex AppMetrica events.
* EventTriggerRegistrationStart
* EventTriggerRegistrationSuccess
* EventTriggerPaymentSuccess
* EventTriggerLoginSuccess

