// Timestamp
// https://www.unixtimestamp.com/

using System;
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using Beebyte.Obfuscator;

public class Switch : MonoBehaviour
{
    // [SkipRename]
    // [SerializeField] 
    // private string enableScene;
    // [SkipRename]
    // [SerializeField] 
    // private string gameScene;

    // [SkipRename]
    // [SerializeField] 
    // private string firstRunKey = "NewPlayer";
    private const string FIRST_RUN = "NewPlayer";

    // Create a new variable that will hold an Integer value.
    // UnixTimestamp Time
    // [SkipRename]
    [SerializeField] 
    private Int32 datePublication = 0; // Date of publication of the application in UnixTimestamp format

    // [SkipRename]
    [SerializeField] 
    private Int32 howManyDaysToWaitOnline = 5; // How many days to switch to offline mode

    private void Start()
    {
        StartCoroutine(StartAfterDelay());
    }

    private IEnumerator StartAfterDelay()
    {

        yield return new WaitForSeconds(0);

        if (!PlayerPrefs.HasKey(FIRST_RUN))
        {

            Int32 unixTimestamp = (int)DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalSeconds; // Get the current time in seconds.
            // Calculate the number of days that have passed since the publication date of the application
            int daysSincePublication = (unixTimestamp - datePublication) / (60 * 60 * 24);

            // Check if the number of days since publication is greater than or equal to the number of days until offline mode
            if (daysSincePublication >= howManyDaysToWaitOnline)
            {
                SceneManager.LoadScene(1);
            }else{
                PlayerPrefs.SetInt(FIRST_RUN, 1);
                SceneManager.LoadScene(2);
            }
            
        }else{
            SceneManager.LoadScene(2);
        }
        
    }

}
