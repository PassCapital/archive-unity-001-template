# Google Play In-app Review Plugin for Unity

*com.google.play.review*

## Overview

The Google Play In-app Review Plugin for Unity lets you prompt users to submit
Play Store ratings and reviews without the inconvenience of leaving your game.

Refer to the
[documentation](//developer.android.com/guide/playcore/in-app-review/unity)
and
[Runtime API reference](//developer.android.com/reference/unity/namespace/Google/Play/Review)
for more information.

