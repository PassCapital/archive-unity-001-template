// Deprecated - See SuppressLogAttribute.cs
