﻿
#if UNITY_ANDROID
namespace DeadMosquito.AndroidGoodies
{
	public enum AGDialogTheme
	{
		Default = -1,
		Light = 0,
		Dark = 1
	}
}
#endif