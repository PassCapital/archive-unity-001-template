// This asset was uploaded by https://unityassetcollection.com


namespace Beebyte.Obfuscator
{
	/**
	 * Empty class to ensure old versions of this class are wiped out on upgrades.
	 *
	 * @See PipelineHook.cs for the build pipeline entry points
	 */
	public class Postbuild
	{
	}
}