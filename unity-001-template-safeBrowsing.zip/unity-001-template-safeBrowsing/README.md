# Project

## 2023.06.01 Addition SafeBrowsing

* Disable webView.Load call if SafeBrowsing is launched before it
* Addition WRITE_EXTERNAL_STORAGE to Manifest
* Set to FALSE for UniWebView multi-window functionality
* Enabled file support in UniWebView
* Added ability to enable SafeBrowsingMode from hosting
* Enable camera support for iOS in UniWebView
* Disabled webView.Load call if SafeBrowsing was launched before it
* Used #if UNITY_ANDROID for SafeBrowsing


## 2023.06.23 Events Yandex AppMetrica

* Added Yandex AppMetrica events.
* EventTriggerRegistrationStart
* EventTriggerRegistrationSuccess
* EventTriggerPaymentSuccess
* EventTriggerLoginSuccess
